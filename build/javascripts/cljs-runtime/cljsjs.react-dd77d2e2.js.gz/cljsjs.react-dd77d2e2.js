goog.provide('cljsjs.react');
goog.require('cljs.core');
var module$node_modules$react$index=shadow.js.require("module$node_modules$react$index", {});
goog.exportSymbol("React",module$node_modules$react$index);

//# sourceMappingURL=cljsjs.react.js-923daccb.map
