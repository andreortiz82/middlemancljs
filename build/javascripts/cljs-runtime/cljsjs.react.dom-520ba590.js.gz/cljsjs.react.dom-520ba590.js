goog.provide('cljsjs.react.dom');
goog.require('cljs.core');
var module$node_modules$react$index=shadow.js.require("module$node_modules$react$index", {});
var module$node_modules$react_dom$index=shadow.js.require("module$node_modules$react_dom$index", {});
goog.object.set(module$node_modules$react$index,"DOM",module$node_modules$react_dom$index);
goog.exportSymbol("ReactDOM",module$node_modules$react_dom$index);

//# sourceMappingURL=cljsjs.react.dom.js-1f9398e1.map
